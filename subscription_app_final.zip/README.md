# Subscription App

Flutter project for catering payment management.
Push to GitHub to trigger Actions build for APK.
